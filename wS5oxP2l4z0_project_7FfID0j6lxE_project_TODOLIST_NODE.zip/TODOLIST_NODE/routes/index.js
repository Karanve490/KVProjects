// variables including our express server

const express=require("express");

const router=express.Router();

console.log("router loaded successfully");

// for accessing in main index.js
module.exports=router;