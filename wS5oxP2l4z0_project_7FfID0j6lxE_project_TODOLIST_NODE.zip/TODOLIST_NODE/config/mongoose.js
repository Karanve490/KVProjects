const mongoose=require("mongoose");

// connect to database
 mongoose.connect("mongodb://localhost/todo_list_db");

 //to check whether connected successfully or not

 const db=mongoose.connection;

 //for error checking

 db.on("error", console.error.bind(console,"error in it"));

 //succesfull connection

 db.once("open", function()
 {
    console.log("successfull connection");
 })