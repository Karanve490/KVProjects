const mongoose= require("mongoose");

// for making our schema to our data base

const todoSchema= new mongoose.Schema(
    {
        // we have used schema as : description, category, and date. which is obviously required
        description :
        {
            type: String,
            required: true
        },
        category :
        {
            type: String,
            required: true
        },
        date :
        {
            type: Date,
            required: true
        }
    }
   
);

const todo=mongoose.model("todo", todoSchema);
module.exports=todo;